<?php

namespace Source;
class MyClass
{
    public $namespace = __NAMESPACE__;
}