<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Fullstack PHP - Iniciando um projeto</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<?php
$start = "Vamos Começar";
echo "<h1>Olá Mundo! {$start}</h1>";
echo "<p id='js'>Loading...</p>"
?>
<script src="assets/scripts.js"></script>
</body>
</html>
