<?php

namespace App;

class Template
{
public $app;
}